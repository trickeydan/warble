module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const tweetTable = context.bindings.tweetTable;

    var results = []

    for (i in tweetTable){
        var tweet = {
            username: tweetTable[i]["username"],
            message: tweetTable[i]["message"]
        }

        results.push(tweet)
    }

    if(tweetTable){
        context.res = {
            status: 200,
            body: results
        }
    }else{
        context.res = {
            status: 400,
            body: {}
        }
    }
};