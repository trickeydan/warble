module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const followingTable = context.bindings.followingTable;

    if(followingTable){
        var results = []

        for (i in followingTable){
            results.push(followingTable[i]["follows"])
        }
        context.res = {
            status: 200,
            body: results
        }
    }else{
        context.res = {
            status: 400,
            body: {}
        }
    }
};