module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const tweetTable = context.bindings.tweetTable;
    const followingTable = context.bindings.followingTable;
    const username = req.query.username || req.body.username;

    var results = []

    var following = []

    if(followingTable){
        //Process results
        for(i in followingTable){
            following.push(followingTable[i]["follows"])
        }
    }

    

    for (i in tweetTable){

        var postUsername = tweetTable[i]["username"]

        if(username == "" || username == postUsername || following.includes(postUsername)){
            var tweet = {
                username: postUsername,
                message: tweetTable[i]["message"],
            }

            results.push(tweet)
        }
    }

    if(tweetTable){
        context.res = {
            status: 200,
            body: results
        }
    }else{
        context.res = {
            status: 400,
            body: {}
        }
    }
};