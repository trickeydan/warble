module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const userInTable = context.bindings.userInTable; // Get to ensure it exists.
    const followsInTable = context.bindings.followsInTable; // Get to ensure it exists.
    const existsInTable = context.bindings.existsInTable; // Get to ensure it does not exist.

    const username = req.query.username || req.body.username;
    const follows = req.query.follows || req.body.follows;


    if(userInTable && followsInTable){
        if(existsInTable && existsInTable.length > 0){
            context.res = {
                status: 400,
                body: {status: "Already following."}
            }
        }else{

            if(username === follows){
                context.res = {
                    status: 400,
                    body: {status: "Cannot follow same user."}
                }
            }else{
                var timestamp = new Date().getTime(); // Crude UUID-like thing
                var followersData = {
                    PartitionKey: "part",
                    RowKey: timestamp,
                    username: username,
                    follows: follows
                }

                context.bindings.followersOutTable = followersData;
                context.res = {
                    status: 201,
                    body: {
                        username: username,
                        follows: follows
                    }
                }
            }
        }
    }else{
        context.res = {
            status: 400,
            body: {status: "Invalid username."}
        }
    }
};